import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      "callForService": "Call For Service",
      "teamMembers": "Team Members",
      "edit": "Edit",
      "name": "Name",
      "phone": "Phone Number",
      "works": "Work List"
    }
  },
  bn: {
    translation: {
      "callForService": "সার্ভিসের জন্য ডাকুন",
      "teamMembers": "টিম মেম্বার",
      "edit": "এডিট",
      "name": "নাম",
      "phone": "ফোন নম্বর",
      "works": "কাজের তালিকা"
    }
  }
};

i18n.use(initReactI18next).init({
  resources,
  lng: 'bn',
  fallbackLng: 'en',
  interpolation: {
    escapeValue: false
  }
});

export default i18n;